#ifndef _SERVER_CONSTAIN_H_
#define _SERVER_CONSTAIN_H_

#define BUFF_SIZE 1024
#define SERVER_PASSWORD "__SV|!@#$^&*()|SV__"
#define SERVER_REFUSED "__SV|REFUSED|SV__"
#define SERVER_ALLSET "__SV|ALLSET|SV__"
#define MAX_CLIENTS 2

#endif  // _SERVER_CONSTAIN_H_
