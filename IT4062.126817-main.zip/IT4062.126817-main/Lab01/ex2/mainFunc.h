//
//  mainFunc.h
//  Ex2
//
//  Created by Lương Dương on 28/9/2021.
//

#ifndef _MAINFUNC_H_
#define _MAINFUNC_H_

void clearSTDIN(void);
void addScoreBoard(void);
void addStudentScore(void);
void deleteStudentScore(void);
void searchStudentScore(void);
void displayScoreBoard(void);

#endif /* _MAINFUNC_H_ */


