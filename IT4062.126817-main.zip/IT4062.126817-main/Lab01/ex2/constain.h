//
//  constain.h
//  Ex2
//
//  Created by Lương Dương on 28/9/2021.
//

#ifndef _CONSTAIN_H_
#define _CONSTAIN_H_


#define MAX_LENGTH_STUDENT_ID 20
#define MAX_LENGTH_STUDENT_NAME 50
#define MAX_LENGTH_SUBJECT_ID 20
#define MAX_LENGTH_SUBJECT_NAME 50
#define MAX_LENGTH_SEMESTER 20


#endif /* _CONSTAIN_H_ */


